name = "Sam"
num = 42
foodOne = "Sushi"
foodTwo = "Teriyaki"

# part 1
print ("Hello World")

# part 2a
print ("Hello", name, "!")

# part 2b
print ("Hello " + name + "!")

# part 3a
print ("Hello", num, "!")

# part 3b
print ("Hello " + num + "!")

# part 3b(Ninja Bonus)
print ("Hello " + str(num) + "!")

# part 4a
print ("I love to eat {} and {}.".format("Sushi", "Teriyaki"))

# part 4b
print (f"I love to eat {foodOne} and {foodTwo}.")

# Ninja Bonus
nameTwo = "sam"
print (nameTwo.capitalize())

casef = "SAM"
print (casef.casefold())

isal = "sam123"
print (isal.isalnum())

print (nameTwo.upper())